package com.lc.autotrader

import org.junit.Assert.assertFalse
import org.junit.Test

class TradingModeTest {
    @Test fun liveTradingIsDisabledInBuild() {
        assertFalse(BuildConfig.LIVE_TRADING_ENABLED)
    }
}
