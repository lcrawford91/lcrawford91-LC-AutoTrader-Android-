package com.lc.autotrader.core.model

enum class TradingMode { PAPER, LIVE }

data class AutomationStatus(
    val enabled: Boolean = false,
    val killSwitchLatched: Boolean = true,
    val liveSubmissionEnabled: Boolean = false,
)
