package com.lc.autotrader.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { TradingHome() } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TradingHome() {
    Scaffold(topBar = { TopAppBar(title = { Text("LC AutoTrader") }) }) { inset ->
        Column(
            modifier = Modifier.fillMaxSize().padding(inset).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Card {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Live trading is disabled", style = MaterialTheme.typography.titleMedium)
                    Text("No account is connected in this scaffold. Balances and prices are unavailable.")
                }
            }
            Card {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Automation: OFF", style = MaterialTheme.typography.titleMedium)
                    Text("Kill-switch: LATCHED · New strategy orders blocked")
                }
            }
            Card {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Next build step", style = MaterialTheme.typography.titleMedium)
                    Text("Connect a read-only account view through the authenticated backend, then reconcile balances before adding order actions.")
                }
            }
        }
    }
}
