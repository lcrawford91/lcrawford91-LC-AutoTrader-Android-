# LC AutoTrader — Android build scaffold

Native Kotlin/Jetpack Compose Android project with a fail-closed trading mode and an APK build workflow. **Live trading is disabled.** This is not a connected brokerage client.

## Getting started

- [Build the debug APK](docs/BUILD_GUIDE.md)
- [Development roadmap and release gates](docs/DEVELOPMENT_ROADMAP.md)
- [Backend trust boundary](backend/README.md)
- [Strategy learning and evaluation](backend/learning/README.md)

## Project layout

- `app/`: Android application, trading policy contracts, and unit tests.
- `.github/workflows/build-apk.yml`: GitHub Actions Android test and APK build.
- `backend/`: architecture notes only; no running backend service.
- `docs/`: build instructions and phased delivery roadmap.

## Safety and limitations

No brokerage integration, account balances, trading endpoints, credentials, or signed release APK are included. `BuildConfig.LIVE_TRADING_ENABLED` remains `false`; the UI indicates that automation is off. The execution gateway is only a contract, not an implemented order adapter. Do not put API secrets in the APK.

The £10 order cap and £3 daily loss latch are design constraints described in the roadmap, not verified live protections. Validate any proposed risk controls in an actual backend before considering live activation.
