# Build LC AutoTrader Android debug APK

This builds an **unconnected UI scaffold**. Live trading is disabled and no broker order submission is implemented.

1. Upload the **contents** of this ZIP to the repository root (including `.github/`). Do not upload the enclosing folder as a single nested directory.
2. On GitHub, open **Actions → Build Android APK → Run workflow**. The workflow also runs on pushes to `main`.
3. Open the completed workflow run. Both **Unit tests** and **Build debug APK** must succeed.
4. Under **Artifacts**, download `LC-AutoTrader-debug-apk`, extract it and install `app-debug.apk` on Android after reviewing the source.

The workflow installs JDK 17, Gradle 8.9, and Android SDK platform/build-tools 35. It runs the Android JUnit task (`:app:testDebugUnitTest`), not Python `pytest`.

## Troubleshooting

- **Android SDK not found:** check the **Install Android SDK packages** step and its `ANDROID_HOME`/`ANDROID_SDK_ROOT` environment variables.
- **Gradle or plugin resolution failure:** check the Gradle step and the Android/Kotlin plugin repositories; inspect the first failure in the log.
- **Missing artifact:** the APK build must succeed before upload; the expected path is `app/build/outputs/apk/debug/app-debug.apk`.
- **Install fails:** ensure the artifact ZIP was extracted and your device permits installation from the selected source.

A passing build does **not** prove live trading, authentication, market data, or server-side risk enforcement works. Never enter brokerage credentials into this scaffold.
